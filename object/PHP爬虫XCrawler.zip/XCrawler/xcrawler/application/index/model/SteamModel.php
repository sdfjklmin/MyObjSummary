<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/5/7
 * Time: 14:49
 */

namespace app\index\model;


use think\Model;

class SteamModel extends Model
{

}