<?php
namespace app\crawler\example\steam;

use xcrawler\XCommand;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use xcrawler\XCrawler;
use Symfony\Component\DomCrawler\Crawler;

/**
 * 电影天堂首页爬虫示例
 */
class Index extends XCommand
{
    protected function configure()
    {
        $this->setName('steam:index')
            ->setDescription('steam index crawler');
    }
    #子页面地址
    private $_url = 'http://www.stmbuy.com/pubg' ;
    #根地址
    private $_mainUrl = 'http://www.stmbuy.com' ;
    #当前爬取页数
    private $_i = 18 ;
    #是否开始爬取
    private $_begin = true ;
    #执行
    protected function execute(Input $input, Output $output)
    {
        while ($this->_begin){
            $this->_i ++ ;
            $xcrawler = new XCrawler([
                'name' => $this->getName(),
                'requests' => function() {
//                $url = 'http://www.dytt8.net/';
                    $url = $this->_url.'?page='.$this->_i;
                    yield $url;
                },
                'success' => function($result, $request, $xcrawler, $res_headers) {
                    // 把html的编码从gbk转为utf-8
                    //$result = iconv('GBK', 'UTF-8', $result);
                    $crawler = new Crawler();
                    $crawler->addHtmlContent($result);
                    $list = [];
                    // 通过css选择器遍历列表
                    $tr_selector = 'div.main-content > ul.goods-list li ' ;
                    $crawler->filter($tr_selector)->each(function (Crawler $node, $i) use (&$list) {
                        var_dump('停止');exit();
                        #名称
                        $name = dom_filter($node, 'a > div.goods-item > p.tit', 'html');
                        if (empty($name)) {
                            echo '暂无数据',die() ;
                            return;
                        }
                        #子链接
                        $into = dom_filter($node, 'a', 'attr','href');
                        #图片名称
                        $img = dom_filter($node, 'a > div.goods-item > div.goods-img > img', 'attr','src');
                        #数量
                        $sellNum = dom_filter($node, 'a > div.goods-item p.sec-tit > span', 'html');
                        #最近价格
                        $lowPrice = dom_filter($node, 'a > div.goods-bottom > p > span > strong', 'html');
                        $data = [
                            'into' => $this->_mainUrl.$into ,
                            'name' => $name ,
                            'img' => $img ,
                            'sell_num' => $sellNum ,
                            'low_price' => $lowPrice ,
                        ] ;
                        // data推送到redis队列，以便进一步爬取链接
                        redis()->lpush('steam:detail_queue', json_encode($data));
                        $list[] = $data;
                        //var_dump($data) ;
                    });
                }
            ]);
            $result = $xcrawler->run();
            // 输出爬取结果
            $output->writeln($result);
            // 如果你想在列表爬虫命令内部直接调用详情爬虫，可以通过下面的方法:
            \xcrawler\XConsole::call('steam:detail', [], 'Console');
        }

    }
}