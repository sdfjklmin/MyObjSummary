<?php
// 爬虫命令配置

return [
    'app\crawler\Hello',
    'app\crawler\example\dytt8\Index',
    'app\crawler\example\dytt8\Detail',
    'app\crawler\example\steam\index',
    'app\crawler\example\steam\detail',
];
