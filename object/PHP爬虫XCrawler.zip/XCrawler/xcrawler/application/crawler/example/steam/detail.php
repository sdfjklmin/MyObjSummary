<?php
namespace app\crawler\example\steam;

use xcrawler\XCommand;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use xcrawler\XCrawler;
use Symfony\Component\DomCrawler\Crawler;

/**
 * 电影天堂首页爬虫示例
 */
class Detail extends XCommand
{
    protected function configure()
    {
        $this->setName('steam:detail')
            ->addOption('continue', 'c', Option::VALUE_NONE, 'is continue')
            ->setDescription('steam detail crawler');
    }

    protected function execute(Input $input, Output $output)
    {
        $xcrawler = new XCrawler([
            'name' => $this->getName(),
            'concurrency' => 3,
            'continue' => $input->getOption('continue'),
            'requests' => function() {
                while ($data = redis()->rpop('steam:detail_queue')) {
                    $data = json_decode($data, true);
                    $request = [
                        'uri' => $data['into'],
                        'callback_data' => $data,
                    ];
                    yield $request;
                }
            },
            'success' => function($result, $request, $xcrawler, $res_headers) {
                //$result = iconv('GBK', 'UTF-8', $result);
                $crawler = new Crawler();
                $crawler->addHtmlContent($result);
                $data = $request['callback_data'];
                $tr_selector = 'div.container > div.main-content > div.goods-detail > div.goods-info ' ;
                $crawler->filter($tr_selector)->each(function (Crawler $node, $i) use (&$data) {
                    $price = dom_filter($node, 'p.goods-price > strong', 'html');
                    if (empty($price)) {
                        echo '暂无数据',die() ;
                        return;
                    }
                    $data['price'] = $price ;
                    Db('steam') -> insert($data) ;
                });
            }
        ]);
        $result = $xcrawler->run();
        // 输出爬取结果
        $output->writeln($result);
    }
}